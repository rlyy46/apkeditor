package com.marvis.sixeyes;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SixEyesMod implements ModInitializer {
    public static final String MOD_ID = "sixeyes";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("[SixEyes] loaded");
    }
}
