package com.marvis.sixeyes;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class SixEyesClient implements ClientModInitializer {

    public static final String[] CN = {"LIE", "YIN", "MING", "JIE", "JING", "PO", "SU", "REN"};
    public static final int COOLDOWN = 160;
    public static final long[] CD_END = new long[8];

    private static boolean enabled = true;
    private final boolean[] prev = new boolean[8];
    private static int flashIdx = -1;
    private static long flashEnd = 0;

    @Override
    public void onInitializeClient() {
        HudRenderCallback.EVENT.register((ctx, delta) -> render(ctx));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.world == null || mc.currentScreen != null) {
                return;
            }
            long handle = mc.getWindow().getHandle();
            long now = mc.world.getTime();
            for (int i = 0; i < 8; i++) {
                boolean down = InputUtil.isKeyPressed(handle, GLFW.GLFW_KEY_1 + i);
                if (down && !prev[i]) {
                    trigger(i, mc, now);
                }
                prev[i] = down;
            }
        });
    }

    private void trigger(int i, MinecraftClient mc, long now) {
        if (now < CD_END[i]) {
            return;
        }
        CD_END[i] = now + COOLDOWN;
        flashIdx = i;
        flashEnd = now + 8;

        var player = mc.player;
        double cx = player.getX();
        double cy = player.getY() + 1.0;
        double cz = player.getZ();
        for (int k = 0; k < 24; k++) {
            double a = k / 24.0 * Math.PI * 2.0;
            mc.particleManager.addParticle(ParticleTypes.END_ROD,
                    cx + Math.cos(a) * 1.3, cy, cz + Math.sin(a) * 1.3,
                    -Math.cos(a) * 0.35, 0.08, -Math.sin(a) * 0.35);
        }
        mc.player.sendMessage(Text.literal(CN[i] + " released"), true);
    }

    private void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!enabled || mc.player == null || mc.world == null || mc.options.hudHidden) {
            return;
        }

        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        int n = 8;
        int box = 24;
        int gap = 4;
        int totalW = n * box + (n - 1) * gap;
        int x0 = (w - totalW) / 2;
        int y0 = h - 58;
        long now = mc.world.getTime();

        for (int i = 0; i < n; i++) {
            int x = x0 + i * (box + gap);
            boolean ready = now >= CD_END[i];
            ctx.fill(x, y0, x + box, y0 + box, ready ? 0xC0101018 : 0xC0202028);

            int border;
            if (i == flashIdx && now < flashEnd) {
                border = 0xFF00E5FF;
            } else if (ready) {
                border = 0x90FFFFFF;
            } else {
                border = 0x40FFFFFF;
            }
            ctx.fill(x, y0, x + box, y0 + 1, border);
            ctx.fill(x, y0 + box - 1, x + box, y0 + box, border);
            ctx.fill(x, y0, x + 1, y0 + box, border);
            ctx.fill(x + box - 1, y0, x + box, y0 + box, border);

            if (!ready) {
                long left = CD_END[i] - now;
                int cover = (int) (box * Math.min(1.0, left / (double) COOLDOWN));
                ctx.fill(x + 1, y0 + box - cover, x + box - 1, y0 + box - 1, 0x99000000);
            }

            String label = CN[i];
            int tw = mc.textRenderer.getWidth(label);
            ctx.drawText(mc.textRenderer, label, x + (box - tw) / 2, y0 + 8, ready ? 0xFFFFFFFF : 0xFF808080, false);
        }

        String hint = "Six Eyes  [1-8]";
        int hw = mc.textRenderer.getWidth(hint);
        ctx.drawText(mc.textRenderer, hint, (w - hw) / 2, y0 - 12, 0xFF66E5FF, true);
    }
}
